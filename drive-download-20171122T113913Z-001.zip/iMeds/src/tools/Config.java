/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

/**
 *
 * @author alunodev06
 */
public class Config {
    
    public static final String NOME_DRIVER = "com.mysql.jdbc.Driver";
    public static final String BD_URL = "jdbc:mysql://localhost:3307/mysqllivroautor1x1";
    public static final String BD_LOGIN = "root";
    public static final String BD_SENHA = "123456";
}
