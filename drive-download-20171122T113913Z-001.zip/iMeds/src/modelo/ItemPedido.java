/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author alunodev06
 */
public class ItemPedido {
    public int idItemPedido;
    public int quantidade;
    public Medicamento medicamento;
    public Pedido pedido;
}
