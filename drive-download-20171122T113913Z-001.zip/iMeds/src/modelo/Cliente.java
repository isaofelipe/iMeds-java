/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author alunodev06
 */
public class Cliente {
    public int idCliente;
    public String nome;
    public String CPF;
    public String endereco;
    public String telefone;
    public Usuario usuario;
}
