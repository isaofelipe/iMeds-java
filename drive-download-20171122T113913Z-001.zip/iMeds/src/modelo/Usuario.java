/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Isao Felipe Morigaki
 */
public class Usuario {
    public int idUsuario;
    public String email;
    public String senha;
    public int tipo;
}
